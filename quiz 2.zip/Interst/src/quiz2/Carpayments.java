package quiz2;

public class Carpayments {
	public double price;
	public double down;
	public int months;
	public double rate;
	
	public double monthlypayments(double price, double down, int months, double rate) {
		double principle = price-down;
		double payment = principle*(rate*Math.pow(1+rate, months)/(Math.pow(1+rate, months)-1));
		return payment;	
	}
	public double total(double price, double down, int months, double rate) {
		double loan = price - down;
		return (loan*Math.pow(1+rate, months));
		
	}
}
