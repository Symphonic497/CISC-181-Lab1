package pkgCore;

public class Roll {

	private Die d1;
	private Die d2;
	private int Score;

	public Roll() {
		// TODO: Create an instance of d1 and d2...
		// TODO: Determine 'Score'
		Die d1 = new Die();
		Die d2 = new Die();
		int z = d1.getDieValue();
		int y = d2.getDieValue();
		Score = (z+y);
	}

	public int getScore() {
		return Score;
	}

}
