package pkgCore;

import java.util.LinkedList;

public class Round {

	private int ComeOutScore;
	private eGameResult eGameResult;
	private LinkedList<Roll> rolls = new LinkedList<Roll>();

	public Round() {
		// TODO: Execute Come Out roll, value ComeOutScore
		Roll ComeOutRoll = new Roll();
		rolls.add(ComeOutRoll);
		ComeOutScore = ComeOutRoll.getScore();
		// TODO: Create a loop that will execute a roll until point is made, or
		// seven-out
		boolean pointmade = false;
		if (pointmade == false) {
			Roll z = new Roll();
			rolls.add(z);
			if (z.getScore() == 7)
				pointmade = true;
			if (z.getScore()>4 && z.getScore()<=10 && z.getScore()!=7)
				pointmade = true;
		}
		// TODO: value the eGameResult after the round is complete
		if (rolls.getLast().getScore() == 7)
			eGameResult = pkgCore.eGameResult.SEVEN_OUT;
		else if (rolls.getLast().getScore() == 2 ||rolls.getLast().getScore() == 3 || rolls.getLast().getScore() == 12)
			eGameResult = pkgCore.eGameResult.CRAPS;
		else if (rolls.getLast().getScore() == 11)
			eGameResult = pkgCore.eGameResult.NATURAL;
		else
			eGameResult = pkgCore.eGameResult.POINT;
	}
		


	public int RollCount() {
		// Return the roll count
		return rolls.size();
	}

}
